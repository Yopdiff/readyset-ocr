import SwiftUI

// MARK: - 마감 시간 계산

extension Workplace {
    /// 이 근무가 끝나는 마감 시각 (시작보다 이르면 다음 날). 마감 시간을 모르면 nil
    func closingDate(after start: Date, calendar: Calendar = .current) -> Date? {
        guard let closingMinutes,
              let sameDay = calendar.date(bySettingHour: closingMinutes / 60,
                                          minute: closingMinutes % 60,
                                          second: 0, of: start)
        else { return nil }
        return sameDay <= start ? calendar.date(byAdding: .day, value: 1, to: sameDay) : sameDay
    }
}

enum ClosingTime {
    /// 1320 → "10:00 PM" (기기의 12/24시간 설정을 따름)
    static func text(_ minutes: Int) -> String {
        let date = Calendar.current.date(bySettingHour: minutes / 60, minute: minutes % 60,
                                         second: 0, of: .now) ?? .now
        return date.formatted(date: .omitted, time: .shortened)
    }
    
    /// 시간 선택기의 Date → 자정부터 몇 분
    static func minutes(from date: Date) -> Int {
        let parts = Calendar.current.dateComponents([.hour, .minute], from: date)
        return (parts.hour ?? 0) * 60 + (parts.minute ?? 0)
    }
}

// MARK: - Review의 "몇 시에 마감해요?" 카드

struct ClosingTimeCard: View {
    let workplaceName: String
    let closeShiftCount: Int
    let onSave: (Int) -> Void
    
    @State private var time: Date
    
    init(workplaceName: String, closeShiftCount: Int, initialMinutes: Int?, onSave: @escaping (Int) -> Void) {
        self.workplaceName = workplaceName
        self.closeShiftCount = closeShiftCount
        self.onSave = onSave
        let minutes = initialMinutes ?? 22 * 60      // 처음엔 오후 10시로 제안
        _time = State(initialValue: Calendar.current.date(
            bySettingHour: minutes / 60, minute: minutes % 60, second: 0, of: .now) ?? .now)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("What time does \(workplaceName) close?")
                .font(AppFont.montserrat(15, .semibold, relativeTo: .headline))
            
            Text("\(closeShiftCount) \(closeShiftCount == 1 ? "shift ends" : "shifts end") at closing (“CL”). We'll remember this for next time.")
                .font(AppFont.montserrat(12, relativeTo: .footnote))
                .foregroundStyle(AppColor.primary.opacity(0.7))
                .padding(.top, 4)
            
            HStack {
                Text("Closing time")
                    .font(AppFont.montserrat(14, relativeTo: .subheadline))
                Spacer()
                DatePicker("Closing time", selection: $time, displayedComponents: .hourAndMinute)
                    .labelsHidden()
            }
            .padding(.top, 14)
            
            PrimaryButton(title: "Use this time", minHeight: 44) {
                onSave(ClosingTime.minutes(from: time))
            }
            .padding(.top, 14)
        }
        .padding(16)
        .cardStyle()
    }
}

#Preview {
    ClosingTimeCard(workplaceName: "Café A", closeShiftCount: 3, initialMinutes: nil) { _ in }
        .padding()
}
