import SwiftUI

/// 마스코트 표정
enum MascotExpression: String, CaseIterable {
    case normal      // 세로 타원 눈
    case blink       // 감은 눈
    case happy       // 눈웃음 (⌒ ⌒)
    case sleepy      // 졸린 눈 (◡ ◡)
}

/// 재사용 가능한 마스코트 캐릭터
/// 크기·색·표정·모양(morph)·찌그러짐(squash)·점프(hop)·시선을 밖에서 정할 수 있어요.
struct MascotView: View {
    var size: CGFloat = 120
    var morph: Double = 0                       // 0 네모, 1 동그라미, 2 꽃, 3 별
    var spinsWithMorph = false                  // 변신하며 시계 방향으로 회전 (애니메이션 2)
    var expression: MascotExpression = .normal
    var eyeOpenness: CGFloat = 1                // 1 뜬 눈 ~ 0 감은 눈 (깜빡임용)
    var lookOffset: CGSize = .zero              // 시선 (-1 ~ 1)
    var squash: CGFloat = 0                     // + 납작, − 길쭉 (-1 ~ 1)
    var hop: CGFloat = 0                        // 점프 높이 (0 바닥 ~ 1 가장 높이)
    var tilt: Double = 0                        // 오른쪽 들어올리기 각도 (도)
    var showsGroundShadow = true
    var showsDropShadow = true                  // 몸 뒤로 퍼지는 그림자
    var colors: [Color] = MascotView.defaultColors
    
    static let defaultColors = [Color(hex: 0x93DDFB), Color(hex: 0xA3A6F8), Color(hex: 0xB77CFC)]
    static let shadowColor = Color(hex: 0x9B8CF2)
    
    private var bodyHeight: CGFloat { size * 0.9 }   // 원본 비율 (가로가 조금 더 김)
    
    var body: some View {
        VStack(spacing: size * 0.08) {
            ZStack {
                MascotShape(progress: morph, spinsWithMorph: spinsWithMorph)
                    .fill(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing))
                    .shadow(color: Self.shadowColor.opacity(showsDropShadow ? 0.25 : 0), radius: size * 0.08, y: size * 0.04)
                
                MascotEyes(expression: expression, openness: eyeOpenness, width: size, height: bodyHeight)
                    .offset(x: lookOffset.width * size * 0.05,
                            y: lookOffset.height * size * 0.04)
            }
            .frame(width: size, height: bodyHeight)
            .scaleEffect(x: 1 + squash * 0.12, y: 1 - squash * 0.12, anchor: .bottom)
            .offset(y: -hop * size * 0.25)
            .rotationEffect(.degrees(-tilt), anchor: .bottomLeading)
            
            if showsGroundShadow {
                Ellipse()
                    .fill(Self.shadowColor.opacity(0.18 * (1 - Double(hop) * 0.5)))
                    .frame(width: size * 0.7, height: size * 0.07)
                    .scaleEffect(x: (1 + squash * 0.15) * (1 - hop * 0.3))
            }
        }
        .accessibilityHidden(true)
    }
}

// MARK: - 눈

struct MascotEyes: View {
    let expression: MascotExpression
    var openness: CGFloat = 1
    let width: CGFloat
    let height: CGFloat
    var color: Color = Color(hex: 0x23202B)
    
    private var eyeWidth: CGFloat { width * 0.062 }
    private var eyeHeight: CGFloat { height * 0.13 }
    
    var body: some View {
        ZStack {
            eye.offset(x: -width * 0.13)
            eye.offset(x: width * 0.13)
        }
        .offset(y: -height * 0.02)       // 원본처럼 가운데보다 살짝 위
        .foregroundStyle(color)
        .animation(.easeInOut(duration: 0.15), value: expression)
    }
    
    @ViewBuilder
    private var eye: some View {
        switch expression {
        case .normal, .blink:
            // 뜬 눈·감은 눈 = 같은 캡슐의 높이만 바뀜 (겹쳐 보이지 않음)
            capsuleEye(open: expression == .blink ? 0 : openness)
        case .happy:
            ArcEye(curvesUp: true)
                .stroke(style: StrokeStyle(lineWidth: eyeWidth * 0.7, lineCap: .round))
                .frame(width: eyeWidth * 2.8, height: eyeWidth * 1.3)
        case .sleepy:
            ArcEye(curvesUp: false)
                .stroke(style: StrokeStyle(lineWidth: eyeWidth * 0.7, lineCap: .round))
                .frame(width: eyeWidth * 2.8, height: eyeWidth * 1.3)
        }
    }
    
    /// open: 1 다 뜸 ~ 0 감음 (감을수록 살짝 넓고 납작해짐)
    private func capsuleEye(open: CGFloat) -> some View {
        let clamped = min(max(open, 0), 1)
        return Capsule()
            .frame(width: eyeWidth * (1 + 0.5 * (1 - clamped)),
                   height: max(eyeWidth * 0.55, eyeHeight * clamped))
    }
}

/// 둥근 선 모양 눈 (위로 볼록 = 눈웃음, 아래로 볼록 = 졸림)
struct ArcEye: Shape {
    let curvesUp: Bool
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        if curvesUp {
            path.move(to: CGPoint(x: rect.minX, y: rect.maxY))
            path.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.maxY),
                              control: CGPoint(x: rect.midX, y: rect.minY - rect.height))
        } else {
            path.move(to: CGPoint(x: rect.minX, y: rect.minY))
            path.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.minY),
                              control: CGPoint(x: rect.midX, y: rect.maxY + rect.height))
        }
        return path
    }
}

// MARK: - 반짝 표시 (참고 이미지의 짧은 선 세 개)

struct MascotSparkles: View {
    let size: CGFloat
    var burst: CGFloat = 1                      // 0 숨김 → 1 톡 튀어나옴
    var color: Color = Color(hex: 0x8F7CF0)
    
    var body: some View {
        ZStack {
            ForEach([-40.0, 0.0, 40.0], id: \.self) { degrees in
                Capsule()
                    .fill(color)
                    .frame(width: size * 0.035, height: size * 0.11)
                    .offset(y: -size * (0.06 + 0.05 * burst))
                    .rotationEffect(.degrees(degrees))
            }
        }
        .scaleEffect(0.4 + 0.6 * burst)
        .accessibilityHidden(true)
    }
}

// MARK: - 개발용 테스트 화면 (TODO: 출시 전 삭제)

struct MascotTestView: View {
    @State private var morph = 0.0
    @State private var expression: MascotExpression = .normal
    @State private var squash = 0.0
    @State private var look = 0.0
    
    private var formName: String {
        let names = ["Square", "Circle", "Flower", "Star"]
        let index = Int(morph.rounded()) % names.count
        return names[index]
    }
    
    var body: some View {
        Form {
            Section {
                MascotView(size: 180, morph: morph, expression: expression,
                           lookOffset: CGSize(width: look, height: 0),
                           squash: CGFloat(squash))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 32)
            }
            
            Section("Shape: \(formName)") {
                Slider(value: $morph, in: 0...4)
                Button("Morph to next shape") {
                    withAnimation(.spring(duration: 0.9, bounce: 0.35)) {
                        morph = morph.rounded() + 1
                    }
                }
                Button("Reset to square") {
                    morph = 0
                }
            }
            
            Section("Expression") {
                Picker("Expression", selection: $expression) {
                    ForEach(MascotExpression.allCases, id: \.self) { item in
                        Text(item.rawValue.capitalized).tag(item)
                    }
                }
                .pickerStyle(.segmented)
            }
            
            Section("Squash & look") {
                LabeledContent("Squash") { Slider(value: $squash, in: -1...1) }
                LabeledContent("Look") { Slider(value: $look, in: -1...1) }
            }
        }
        .navigationTitle("Mascot test")
    }
}

/// Settings의 Developer 구역에 넣을 줄
struct MascotTestLinkRow: View {
    var body: some View {
        NavigationLink {
            MascotTestView()
        } label: {
            Text("Mascot test")
        }
    }
}

#Preview {
    HStack(spacing: 24) {
        MascotView(size: 100)
        MascotView(size: 100, expression: .happy)
        MascotView(size: 100, morph: 3)
    }
    .padding()
}
