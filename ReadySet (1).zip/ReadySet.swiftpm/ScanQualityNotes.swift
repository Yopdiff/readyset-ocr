import SwiftUI

/// Review에서 사진 품질·못 읽은 칸 안내
struct ScanQualityNotes: View {
    let image: UIImage
    let result: ExtractionResult
    
    /// 짧은 쪽이 이보다 작으면 저해상도 안내
    private static let minimumShortSide: CGFloat = 600
    
    private var isLowResolution: Bool {
        let width = image.size.width * image.scale
        let height = image.size.height * image.scale
        return min(width, height) < Self.minimumShortSide
    }
    
    /// "Tue, Nov 25 (“6g”)"
    private var unreadableText: String {
        result.unreadableCells
            .sorted { $0.date < $1.date }
            .map { cell in
                let day = cell.date.formatted(.dateTime.weekday(.abbreviated).month(.abbreviated).day())
                return "\(day) (“\(cell.rawText)”)"
            }
            .joined(separator: ", ")
    }
    
    var body: some View {
        let count = result.unreadableCells.count
        
        if isLowResolution || count > 0 {
            VStack(alignment: .leading, spacing: 8) {
                if count > 0 {
                    ReviewNote(text: "Couldn't read \(count) \(count == 1 ? "day" : "days"): \(unreadableText). Add it yourself if you worked that day.")
                }
                if isLowResolution {
                    ReviewNote(text: "This photo is low resolution, so some shifts may be missed. A full-size screenshot works best.")
                }
            }
            .padding(.top, 28)
        }
    }
}
