import SwiftUI

/// 마스코트가 변신하는 모양 (이 순서대로 바뀜)
enum MascotForm: Int, CaseIterable {
    case square, circle, flower, star
}

// MARK: - 모양 = 각도별 반지름 목록

/// 모든 모양을 "중심에서 각 방향까지의 거리" 120개로 표현
/// → 점 개수가 같아서, 섞기만 하면 자연스럽게 변신해요.
struct MascotOutline {
    static let sampleCount = 120
    let radii: [CGFloat]          // 0~1 상자 기준 거리
    
    /// index번째 방향의 각도 (맨 위에서 시작, 시계 방향)
    static func angle(at index: Int) -> CGFloat {
        -CGFloat.pi / 2 + 2 * CGFloat.pi * CGFloat(index) / CGFloat(sampleCount)
    }
    
    /// 네모 → 동그라미 → 꽃 → 별 순서의 모양들 (한 번만 계산)
    static let all: [MascotOutline] = MascotForm.allCases.map { make($0) }
    
    /// progress: 0 네모, 1 동그라미, 2 꽃, 3 별, 4 다시 네모 (소수는 그 사이)
    static func blended(_ progress: Double) -> [CGFloat] {
        let count = Double(all.count)
        var value = progress.truncatingRemainder(dividingBy: count)
        if value < 0 { value += count }
        let index = Int(value)
        let fraction = CGFloat(value - Double(index))
        let from = all[index].radii
        let to = all[(index + 1) % all.count].radii
        return zip(from, to).map { a, b in a + (b - a) * fraction }
    }
    
    private static func make(_ form: MascotForm) -> MascotOutline {
        if form == .square { return MascotOutline(radii: squareRadii) }
        
        let radii: [CGFloat] = (0..<sampleCount).map { index in
            let phase = angle(at: index) + CGFloat.pi / 2      // 맨 위 = 0
            switch form {
            case .circle:
                // 아주 살짝 찌그러진 동그라미
                let wobble = 1 + 0.025 * sin(2 * phase + 1.2) + 0.015 * sin(3 * phase + 0.3)
                return 0.46 * wobble
            case .flower:
                // 둥근 꽃잎 6장 + 꽃잎마다 크기가 조금씩 다르게
                let petals = 0.40 + 0.13 * pow(abs(cos(3 * (phase + 0.06))), 0.6)
                let wobble = 1 + 0.05 * sin(phase + 0.8) + 0.03 * sin(2 * phase + 2.1)
                return petals * wobble
            case .star:
                // 통통한 별 + 팔 길이가 조금씩 다르게
                let wave = (cos(5 * (phase + 0.05)) + 1) / 2
                let star = 0.33 + 0.15 * wave
                let wobble = 1 + 0.05 * sin(phase + 2.3) + 0.03 * sin(3 * phase + 0.4)
                return star * wobble
            case .square:
                return 0.5
            }
        }
        return MascotOutline(radii: radii)
    }
    
    /// 기본 캐릭터 실루엣: 첨부 이미지의 테두리를 120개 방향에서 측정한 값
    /// (맨 위에서 시작해 시계 방향)
    private static let squareRadii: [CGFloat] = [
        0.470, 0.466, 0.462, 0.459, 0.458, 0.458, 0.461, 0.463, 0.466, 0.470,
        0.478, 0.487, 0.500, 0.517, 0.539, 0.562, 0.583, 0.594, 0.594, 0.588,
        0.576, 0.562, 0.546, 0.531, 0.517, 0.506, 0.496, 0.488, 0.481, 0.476,
        0.472, 0.469, 0.468, 0.468, 0.470, 0.474, 0.479, 0.486, 0.495, 0.506,
        0.519, 0.534, 0.552, 0.573, 0.594, 0.609, 0.614, 0.612, 0.602, 0.588,
        0.574, 0.560, 0.547, 0.535, 0.525, 0.516, 0.507, 0.499, 0.492, 0.486,
        0.481, 0.478, 0.477, 0.478, 0.480, 0.483, 0.489, 0.498, 0.511, 0.531,
        0.555, 0.581, 0.604, 0.618, 0.621, 0.615, 0.600, 0.579, 0.557, 0.538,
        0.521, 0.507, 0.495, 0.486, 0.478, 0.472, 0.468, 0.466, 0.465, 0.465,
        0.468, 0.472, 0.477, 0.484, 0.492, 0.502, 0.513, 0.527, 0.543, 0.560,
        0.578, 0.597, 0.616, 0.633, 0.647, 0.653, 0.649, 0.637, 0.618, 0.598,
        0.579, 0.562, 0.546, 0.533, 0.521, 0.510, 0.501, 0.491, 0.482, 0.476
    ]
}

// MARK: - 매끄러운 곡선 도우미

enum MascotPath {
    /// 점들을 모두 지나는 매끄러운 닫힌 경로
    static func closedPath(through points: [CGPoint]) -> Path {
        var path = Path()
        let n = points.count
        guard n > 2 else { return path }
        path.move(to: points[0])
        for i in 0..<n {
            let p0 = points[(i - 1 + n) % n]
            let p1 = points[i]
            let p2 = points[(i + 1) % n]
            let p3 = points[(i + 2) % n]
            let control1 = CGPoint(x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6)
            let control2 = CGPoint(x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6)
            path.addCurve(to: p2, control1: control1, control2: control2)
        }
        path.closeSubpath()
        return path
    }
}

// MARK: - 변신하는 실루엣

/// progress를 바꾸면 모양이 변하는 Shape (withAnimation으로 부드럽게 변신)
struct MascotShape: Shape {
    var progress: Double
    var spinsWithMorph = false      // true면 모양이 바뀌는 만큼 시계 방향으로 회전 (한 모양당 90°)
    
    /// SwiftUI가 애니메이션 중간값을 여기에 넣어줘요 → 실루엣이 연속으로 변함
    var animatableData: Double {
        get { progress }
        set { progress = newValue }
    }
    
    func path(in rect: CGRect) -> Path {
        let radii = MascotOutline.blended(progress)
        let rotation = spinsWithMorph ? CGFloat(progress) * CGFloat.pi / 2 : 0
        var points: [CGPoint] = []
        points.reserveCapacity(radii.count)
        for (index, radius) in radii.enumerated() {
            let angle = MascotOutline.angle(at: index) + rotation
            let x = rect.minX + rect.width * (0.5 + radius * cos(angle))
            let y = rect.minY + rect.height * (0.5 + radius * sin(angle))
            points.append(CGPoint(x: x, y: y))
        }
        return MascotPath.closedPath(through: points)
    }
}
