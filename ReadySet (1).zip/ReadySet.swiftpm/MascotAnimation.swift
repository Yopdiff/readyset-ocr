import SwiftUI

/// 반복 애니메이션 종류
enum MascotAnimationStyle {
    case bouncy     // 애니메이션 1: 늘어나고 통통 튀며 변신
    case spin       // 애니메이션 2: 시계 방향으로 돌며 부드럽게 변신
}

// MARK: - 시간 → 모양·찌그러짐·눈 계산 (화면과 분리된 순수 계산)

enum MascotMotion {
    struct Frame {
        var morph: Double
        var squash: CGFloat
    }
    
    /// 한 모양에서 머무는 비율 (나머지는 변신 시간). 클수록 변신이 빨라요.
    static let holdFraction = 0.52
    
    // MARK: 애니메이션 1 (통통)
    
    /// time초일 때의 모양과 찌그러짐
    static func frame(at time: TimeInterval, cycle: Double) -> Frame {
        let segment = cycle / 4                                   // 모양 하나당 시간
        let round = Int(time / cycle)                             // 몇 번째 바퀴인지
        let t = time.truncatingRemainder(dividingBy: cycle)
        let index = min(Int(t / segment), 3)
        let local = (t - Double(index) * segment) / segment      // 0~1
        
        // 바퀴·모양마다 다른 값 (매번 똑같이 튀지 않게)
        let seed = noise(round * 4 + index)
        let strength = 0.8 + 0.45 * seed
        
        if local < holdFraction {
            // 도착 후: 눌렸다가 천천히 출렁이며 가라앉음 (속도 × 0.9)
            let h = local * segment
            let frequency = (9 + 5 * noise(round * 4 + index + 100)) * 0.9
            let wobble = 0.8 * strength * exp(-2.9 * h) * sin(frequency * h)
            return Frame(morph: Double(index), squash: CGFloat(wobble))
        } else {
            // 변신 중
            let u = (local - holdFraction) / (1 - holdFraction)
            
            // 모양: 살짝 뒤로 움츠렸다가 → 다음 모양을 살짝 지나쳤다 돌아옴
            let eased = easeInOutBack(u, overshoot: 0.9)
            
            // 몸: 처음엔 살짝 눌렸다가(예비 동작) → 위로 쭉 늘어남
            let anticipation = u < 0.2 ? 0.35 * strength * sin(Double.pi * u / 0.2) : 0
            let stretchPart = max(0, (u - 0.15) / 0.85)
            let stretch = -0.7 * strength * sin(Double.pi * stretchPart)
            
            return Frame(morph: Double(index) + eased, squash: CGFloat(anticipation + stretch))
        }
    }
    
    // MARK: 애니메이션 2 (회전)
    
    /// 머무는 시간은 짧게, 튀지 않고 부드럽게 돌며 변신
    static func spinFrame(at time: TimeInterval, cycle: Double) -> Frame {
        let segment = cycle / 4
        let hold = 0.3
        let t = time.truncatingRemainder(dividingBy: cycle)
        let index = min(Int(t / segment), 3)
        let local = (t - Double(index) * segment) / segment
        
        guard local >= hold else { return Frame(morph: Double(index), squash: 0) }
        let u = (local - hold) / (1 - hold)
        let eased = u * u * u * (u * (u * 6 - 15) + 10)          // 시작과 끝이 아주 부드러운 곡선
        return Frame(morph: Double(index) + eased, squash: 0)
    }
    
    // MARK: 눈
    
    /// 눈 뜬 정도: 1 다 뜸 ~ 0 감음 (8.4초 동안 불규칙하게 5번, 한 번은 두 번 연속)
    static func eyeOpenness(at time: TimeInterval) -> CGFloat {
        let blinkStarts: [Double] = [0.6, 2.4, 3.9, 4.15, 6.3]
        let t = time.truncatingRemainder(dividingBy: 8.4)
        var openness: Double = 1
        for start in blinkStarts {
            let d = t - start
            if d >= 0 && d < 0.07 {
                openness = min(openness, 1 - d / 0.07)           // 감는 중
            } else if d >= 0.07 && d < 0.10 {
                openness = 0                                     // 감은 상태
            } else if d >= 0.10 && d < 0.19 {
                openness = min(openness, (d - 0.10) / 0.09)      // 뜨는 중
            }
        }
        return CGFloat(openness)
    }
    
    // MARK: 도우미
    
    /// 시작과 끝에서 살짝 넘쳤다 돌아오는 곡선 (말랑한 느낌)
    private static func easeInOutBack(_ x: Double, overshoot: Double) -> Double {
        let c = overshoot * 1.525
        if x < 0.5 {
            let a = 2 * x
            return (a * a * ((c + 1) * a - c)) / 2
        } else {
            let a = 2 * x - 2
            return (a * a * ((c + 1) * a + c) + 2) / 2
        }
    }
    
    /// 같은 숫자에는 항상 같은 0~1 값 (불규칙하지만 예측 가능한 값)
    private static func noise(_ n: Int) -> Double {
        let x = sin(Double(n) * 12.9898) * 43758.5453
        return x - floor(x)
    }
}

// MARK: - 반복 애니메이션 마스코트 (재사용 컴포넌트)

/// 계속 변신하다가, isFinished가 true가 되면 "띠롱!" 완료 모션
struct AnimatedMascot: View {
    var size: CGFloat = 140
    var style: MascotAnimationStyle = .bouncy
    var isFinished = false
    var cycleDuration: Double = 4.6                 // 한 바퀴 시간 (속도 조절)
    var showsDropShadow = true
    var colors: [Color] = MascotView.defaultColors
    
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var startDate = Date()
    
    // 완료 모션 상태
    @State private var finishMorph: Double?         // 완료 후 모양 (nil이면 반복 중)
    @State private var finishSquash: CGFloat = 0
    @State private var finishTilt: Double = 0       // 오른쪽 들어올리기 각도
    @State private var isSmiling = false
    @State private var sparkleBurst: CGFloat = 0
    @State private var sparkleOpacity: Double = 0
    
    var body: some View {
        TimelineView(.animation(minimumInterval: nil, paused: finishMorph != nil)) { context in
            let time = context.date.timeIntervalSince(startDate)
            let looping = loopingFrame(at: time)
            
            MascotView(
                size: size,
                morph: finishMorph ?? looping.morph,
                spinsWithMorph: style == .spin,
                expression: isSmiling ? .happy : .normal,
                eyeOpenness: finishMorph != nil ? 1 : MascotMotion.eyeOpenness(at: time),
                squash: finishMorph != nil ? finishSquash : looping.squash,
                tilt: finishTilt,
                showsDropShadow: showsDropShadow,
                colors: colors
            )
            .background {
                // 캐릭터 뒤에서 양쪽으로 톡 튀어나오는 별
                MascotStarBurst(size: size, burst: sparkleBurst, colors: colors)
                    .opacity(sparkleOpacity)
            }
        }
        .onChange(of: isFinished) { _, finished in
            if finished { finish() }
        }
        .onAppear {
            if isFinished { finish() }
        }
    }
    
    private func loopingFrame(at time: TimeInterval) -> MascotMotion.Frame {
        if reduceMotion { return MascotMotion.Frame(morph: 0, squash: 0) }
        switch style {
        case .bouncy: return MascotMotion.frame(at: time, cycle: cycleDuration)
        case .spin:   return MascotMotion.spinFrame(at: time, cycle: cycleDuration)
        }
    }
    
    /// 띠롱! 움츠리기 → 오른쪽 들어올리기(눈웃음 + 별) → 내려놓기
    private func finish() {
        guard finishMorph == nil else { return }
        let time = Date().timeIntervalSince(startDate)
        let current = loopingFrame(at: time).morph
        let target = (current / 4).rounded() * 4
        
        if reduceMotion {
            finishMorph = target
            isSmiling = true
            return
        }
        
        // 1. 네모로 돌아오면서 살짝 움츠리기
        withAnimation(.spring(duration: 0.45, bounce: 0.3)) {
            finishMorph = target
        }
        withAnimation(.easeOut(duration: 0.12)) {
            finishSquash = 0.5
        }
        
        Task { @MainActor in
            // 2. 띠롱! 오른쪽을 기우뚱 들어올리며 눈웃음 + 별이 톡톡
            try? await Task.sleep(for: .seconds(0.12))
            isSmiling = true
            withAnimation(.spring(duration: 0.35, bounce: 0.45)) {
                finishTilt = 10
                finishSquash = -0.2
            }
            withAnimation(.spring(duration: 0.6, bounce: 0.5)) {
                sparkleBurst = 1
                sparkleOpacity = 1
            }
            
            // 3. 잠깐 유지 → 통 내려놓으며 살짝 출렁, 별 사라짐
            try? await Task.sleep(for: .seconds(0.5))
            withAnimation(.spring(duration: 0.45, bounce: 0.45)) {
                finishTilt = 0
                finishSquash = 0
            }
            withAnimation(.easeOut(duration: 0.3)) {
                sparkleOpacity = 0
            }
        }
    }
}

// MARK: - 완료 별 (크기가 다른 별 3개가 양쪽에서 시간차로 톡톡)

struct MascotStarBurst: View {
    let size: CGFloat
    var burst: CGFloat = 1                      // 0 숨김 → 1 다 튀어나옴
    var colors: [Color] = MascotView.defaultColors
    
    /// 별 하나: 도착 위치(캐릭터 크기 기준), 크기, 나오는 순서(시간차), 회전
    private struct StarSpec {
        let x: CGFloat
        let y: CGFloat
        let scale: CGFloat
        let delay: CGFloat
        let angle: Double
    }
    
    private let stars: [StarSpec] = [
        StarSpec(x: 0.66, y: -0.28, scale: 0.22, delay: 0.00, angle: 14),    // 오른쪽 위, 큰 별
        StarSpec(x: -0.64, y: -0.12, scale: 0.15, delay: 0.12, angle: -18),  // 왼쪽, 중간 별
        StarSpec(x: 0.58, y: 0.16, scale: 0.10, delay: 0.22, angle: -8)      // 오른쪽 아래, 작은 별
    ]
    
    var body: some View {
        ZStack {
            ForEach(stars.indices, id: \.self) { index in
                starView(stars[index])
            }
        }
        .accessibilityHidden(true)
    }
    
    private func starView(_ star: StarSpec) -> some View {
        // 자기 차례가 되면 0 → 1 (용수철 효과로 살짝 넘쳤다 돌아옴)
        let progress = max(0, (burst - star.delay) / (1 - star.delay))
        let travel = 0.4 + 0.6 * progress           // 캐릭터 가까이에서 바깥으로
        return SparkleStar()
            .fill(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing))
            .frame(width: size * star.scale, height: size * star.scale)
            .scaleEffect(progress)
            .rotationEffect(.degrees(star.angle * Double(progress)))
            .offset(x: size * star.x * travel, y: size * star.y * travel)
    }
}

/// 통통한 작은 별 (로딩 중 변신하는 별과 같은 느낌)
struct SparkleStar: Shape {
    func path(in rect: CGRect) -> Path {
        let count = 60
        var points: [CGPoint] = []
        for i in 0..<count {
            let angle = -CGFloat.pi / 2 + 2 * CGFloat.pi * CGFloat(i) / CGFloat(count)
            let wave = (cos(5 * (angle + CGFloat.pi / 2)) + 1) / 2
            let radius = 0.30 + 0.20 * wave
            points.append(CGPoint(x: rect.midX + rect.width * radius * cos(angle),
                                  y: rect.midY + rect.height * radius * sin(angle)))
        }
        return MascotPath.closedPath(through: points)
    }
}

// MARK: - 개발용 테스트 화면 (TODO: 출시 전 삭제)

struct MascotAnimationTestView: View {
    @State private var isFinished = false
    @State private var runID = UUID()
    
    var body: some View {
        VStack(spacing: 32) {
            Spacer()
            HStack(spacing: 40) {
                VStack(spacing: 16) {
                    AnimatedMascot(size: 130, style: .bouncy, isFinished: isFinished, cycleDuration: 3.6)
                    Text("Animation 1")
                        .font(AppFont.montserrat(14, .semibold, relativeTo: .headline))
                }
                VStack(spacing: 16) {
                    AnimatedMascot(size: 130, style: .spin, isFinished: isFinished, cycleDuration: 3.6)
                    Text("Animation 2")
                        .font(AppFont.montserrat(14, .semibold, relativeTo: .headline))
                }
            }
            .id(runID)
            
            Text(isFinished ? "Done!" : "Looping…")
                .font(AppFont.montserrat(13, relativeTo: .subheadline))
                .foregroundStyle(AppColor.primary.opacity(0.7))
            Spacer()
            Button(isFinished ? "Restart" : "Finish") {
                if isFinished {
                    isFinished = false
                    runID = UUID()          // 처음부터 다시
                } else {
                    isFinished = true
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(AppColor.primary)
        }
        .padding(24)
        .navigationTitle("Mascot animation")
    }
}

struct MascotAnimationTestLinkRow: View {
    var body: some View {
        NavigationLink {
            MascotAnimationTestView()
        } label: {
            Text("Mascot animation")
        }
    }
}

#Preview {
    HStack(spacing: 32) {
        AnimatedMascot(size: 120, style: .bouncy)
        AnimatedMascot(size: 120, style: .spin)
    }
}
