import SwiftUI

// MARK: - 단계

/// 튜토리얼 순서 (앱을 껐다 켜도 이어가도록 이름으로 저장)
enum TutorialStep: String, CaseIterable {
    case addSchedule        // Home: Add Schedule 버튼
    case choosePhoto        // Add Schedule: 사진 선택 칸
    case findShifts         // Add Schedule: Find my shifts 버튼
    case reviewWorkplace    // Review: 직장 고르기
    case reviewName         // Review: 근무표 속 내 이름
    case reviewShifts       // Review: 근무 목록
    case reviewSave         // Review: Add my shifts 버튼
    case manualEntry        // 직접 입력 화면 (근무표를 못 읽었을 때)
    case shiftsAdded        // Home: 근무 추가 완료 → 알람 설정으로
    case wakeUpAlarm        // Settings: Wake-up alarm 줄
    case reminders          // Settings: Shift reminders 줄 + 알림 허용
    case finished           // 축하
    
    /// 강조할 대상 (nil이면 스포트라이트 없이 말풍선만)
    var target: TutorialTarget? {
        switch self {
        case .addSchedule:     .addScheduleButton
        case .choosePhoto:     .photoPicker
        case .findShifts:      .findShiftsButton
        case .reviewWorkplace: .reviewWorkplace
        case .reviewName:      .reviewName
        case .reviewShifts:    .reviewShifts
        case .reviewSave:      .reviewSaveButton
        case .wakeUpAlarm:     .wakeUpAlarmRow
        case .reminders:       .remindersRow
        case .manualEntry, .shiftsAdded, .finished: nil
        }
    }
    
    func message(name: String) -> String {
        switch self {
        case .addSchedule:     "Let’s add your schedule! Tap here to upload a screenshot."
        case .choosePhoto:     "Pick a screenshot of your work schedule."
        case .findShifts:      "Now tap here. I’ll find your shifts for you."
        case .reviewWorkplace: "Pick the workplace this schedule is for."
        case .reviewName:      "Now find your name on the schedule. Tap it if it’s not right."
        case .reviewShifts:    "Check your shifts. Tap one to fix it."
        case .reviewSave:      "Looks good? Add them!"
        case .manualEntry:     "No problem! Fill in your shift and tap Save."
        case .shiftsAdded:     "Your shifts are in! Next, let’s set up your alarms."
        case .wakeUpAlarm:     "Your wake-up alarm rings before each shift. Tap here anytime to change when."
        case .reminders:       "I’ll also remind you before your shifts. Allow notifications so you don’t miss them."
        case .finished:        name.isEmpty ? "You’re all set!" : "You’re all set, \(name)!"
        }
    }
    
    /// 말풍선 버튼 (nil이면 강조된 진짜 버튼을 눌러야 넘어감)
    var primaryTitle: String? {
        switch self {
        case .reviewWorkplace, .reviewName, .reviewShifts, .wakeUpAlarm: "Next"
        case .shiftsAdded:  "Set up alarms"
        case .reminders:    "Allow notifications"
        case .finished:     "Done"
        default:            nil
        }
    }
}

/// 스포트라이트로 강조할 수 있는 화면 요소 이름표
enum TutorialTarget: Hashable {
    case addScheduleButton, photoPicker, findShiftsButton
    case reviewWorkplace, reviewName, reviewShifts, reviewSaveButton
    case wakeUpAlarmRow, remindersRow
}

// MARK: - 진행 관리

/// 지금 튜토리얼이 몇 단계인지 관리하고 기기에 저장 (도중에 꺼도 이어서)
@MainActor
final class TutorialController: ObservableObject {
    @Published private(set) var step: TutorialStep?
    @Published var requestedTab: AppTab?            // 튜토리얼이 탭을 바꿔달라고 요청할 때
    
    private static let stepKey = "tutorialStep"
    
    init() {
        startIfPending()
    }
    
    var isActive: Bool { step != nil }
    
    /// 말풍선에서 불러줄 이름
    var userName: String {
        UserDefaults.standard.string(forKey: AppStorageKey.userName) ?? ""
    }
    
    /// 온보딩에서 Show me how를 눌렀다면 시작 (저장된 단계가 있으면 거기서부터)
    func startIfPending() {
        let defaults = UserDefaults.standard
        guard defaults.bool(forKey: AppStorageKey.tutorialPending) else { return }
        step = defaults.string(forKey: Self.stepKey).flatMap(TutorialStep.init(rawValue:)) ?? .addSchedule
    }
    
    /// 지금 단계가 current일 때만 다음으로 (다른 화면에서 잘못 넘어가지 않게)
    func advance(from current: TutorialStep, to next: TutorialStep) {
        advance(fromAny: [current], to: next)
    }
    
    /// 지금 단계가 목록 중 하나일 때만 다음으로
    func advance(fromAny steps: [TutorialStep], to next: TutorialStep) {
        guard let step, steps.contains(step) else { return }
        withAnimation(.easeInOut(duration: 0.25)) {
            self.step = next
        }
        UserDefaults.standard.set(next.rawValue, forKey: Self.stepKey)
    }
    
    /// Home의 "Set up alarms" → Settings 탭으로
    func goToSettings() {
        guard step == .shiftsAdded else { return }
        advance(from: .shiftsAdded, to: .wakeUpAlarm)
        requestedTab = .settings
    }
    
    /// 건너뛰기·완료: 튜토리얼 끝 (다시 나오지 않음)
    func end() {
        withAnimation(.easeInOut(duration: 0.25)) {
            step = nil
        }
        UserDefaults.standard.removeObject(forKey: Self.stepKey)
        UserDefaults.standard.set(false, forKey: AppStorageKey.tutorialPending)
    }
    
    /// 개발용: 처음부터 다시 (TODO: 출시 전 삭제)
    func restart() {
        UserDefaults.standard.set(true, forKey: AppStorageKey.tutorialPending)
        UserDefaults.standard.removeObject(forKey: Self.stepKey)
        withAnimation(.easeInOut(duration: 0.25)) {
            step = .addSchedule
        }
        requestedTab = .home
    }
}

// MARK: - 이름표 위치 모으기

struct TutorialAnchorKey: PreferenceKey {
    static let defaultValue: [TutorialTarget: Anchor<CGRect>] = [:]
    
    static func reduce(value: inout [TutorialTarget: Anchor<CGRect>],
                       nextValue: () -> [TutorialTarget: Anchor<CGRect>]) {
        value.merge(nextValue()) { _, new in new }
    }
}

extension View {
    /// 이 요소에 튜토리얼 이름표 붙이기
    func tutorialTarget(_ target: TutorialTarget) -> some View {
        anchorPreference(key: TutorialAnchorKey.self, value: .bounds) { [target: $0] }
    }
    
    /// 이 화면 위에 튜토리얼 띄우기 (step이 nil이면 아무것도 안 보임)
    func tutorialOverlay(step: TutorialStep?, name: String,
                         onPrimary: @escaping () -> Void,
                         onSkip: @escaping () -> Void) -> some View {
        overlayPreferenceValue(TutorialAnchorKey.self) { anchors in
            if let step {
                TutorialOverlay(step: step, name: name, anchors: anchors,
                                onPrimary: onPrimary, onSkip: onSkip)
                .transition(.opacity)
            }
        }
    }
    
    /// 화면에서 쓰기 쉬운 버전: 이 화면이 담당하는 단계일 때만 보여줌
    @MainActor
    func tutorialOverlay(_ tutorial: TutorialController,
                         showing steps: Set<TutorialStep>,
                         isHidden: Bool = false,
                         onPrimary: @escaping (TutorialStep) -> Void = { _ in }) -> some View {
        let current = tutorial.step
        let isMine = current.map { steps.contains($0) } ?? false
        let visible: TutorialStep? = (isMine && !isHidden) ? current : nil
        return tutorialOverlay(
            step: visible,
            name: tutorial.userName,
            onPrimary: { if let current { onPrimary(current) } },
            onSkip: { tutorial.end() }
        )
    }
}

// MARK: - 스포트라이트 + 말풍선

struct TutorialOverlay: View {
    let step: TutorialStep
    let name: String
    let anchors: [TutorialTarget: Anchor<CGRect>]
    let onPrimary: () -> Void
    let onSkip: () -> Void
    
    @State private var isPulsing = false
    
    var body: some View {
        GeometryReader { proxy in
            let spot = spotlightRect(in: proxy)
            
            ZStack(alignment: .topLeading) {
                // 어두운 막 (강조 부분만 뚫림). 터치는 막지 않음
                SpotlightShape(cutout: spot)
                    .fill(Color.black.opacity(0.45), style: FillStyle(eoFill: true))
                    .allowsHitTesting(false)
                
                // 강조 테두리 (살짝 숨 쉬듯)
                if let spot {
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(Color.white, lineWidth: 2)
                        .frame(width: spot.width, height: spot.height)
                        .scaleEffect(isPulsing ? 1.03 : 1)
                        .position(x: spot.midX, y: spot.midY)
                        .allowsHitTesting(false)
                }
                
                bubbleLayer(spot: spot, size: proxy.size)
            }
        }
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true)) {
                isPulsing = true
            }
        }
    }
    
    private func spotlightRect(in proxy: GeometryProxy) -> CGRect? {
        guard let target = step.target, let anchor = anchors[target] else { return nil }
        return proxy[anchor].insetBy(dx: -8, dy: -8)
    }
    
    /// 강조 대상이 위쪽이면 말풍선은 아래, 아래쪽이면 위. 대상이 없으면 가운데
    @ViewBuilder
    private func bubbleLayer(spot: CGRect?, size: CGSize) -> some View {
        let bubble = TutorialBubble(
            message: step.message(name: name),
            primaryTitle: step.primaryTitle,
            isCelebration: step == .finished,
            onPrimary: onPrimary,
            onSkip: onSkip
        )
            .frame(maxWidth: 380)
            .padding(.horizontal, 16)
        
        VStack(spacing: 0) {
            if let spot {
                if spot.midY < size.height * 0.5 {
                    Color.clear.frame(height: spot.maxY + 12)
                    bubble
                    Spacer(minLength: 0)
                } else {
                    Spacer(minLength: 0)
                    bubble
                    Color.clear.frame(height: max(0, size.height - spot.minY + 12))
                }
            } else if step == .manualEntry {
                Spacer(minLength: 0)
                bubble
                Color.clear.frame(height: 110)        // 아래쪽 (입력 칸을 가리지 않게)
            } else {
                Spacer(minLength: 0)
                bubble
                Spacer(minLength: 0)
            }
        }
        .frame(width: size.width, height: size.height)
    }
}

/// 화면 전체를 덮되, cutout 부분만 뚫린 모양
struct SpotlightShape: Shape {
    var cutout: CGRect?
    
    func path(in rect: CGRect) -> Path {
        var path = Path(rect)
        if let cutout {
            path.addRoundedRect(in: cutout, cornerSize: CGSize(width: 14, height: 14))
        }
        return path
    }
}

// MARK: - 말풍선 (작은 캐릭터 + 문구 + 버튼)

struct TutorialBubble: View {
    let message: String
    let primaryTitle: String?
    var isCelebration = false
    let onPrimary: () -> Void
    let onSkip: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .center, spacing: 12) {
                IdleMascot(size: 44, mood: isCelebration ? .happy : .calm)
                Text(message)
                    .font(AppFont.montserrat(14, .medium, relativeTo: .subheadline))
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            
            HStack {
                if !isCelebration {
                    Button("Skip tutorial", action: onSkip)
                        .font(AppFont.montserrat(12, relativeTo: .footnote))
                        .underline()
                        .foregroundStyle(AppColor.primary.opacity(0.6))
                        .buttonStyle(.plain)
                }
                Spacer()
                if let primaryTitle {
                    Button(action: onPrimary) {
                        Text(primaryTitle)
                            .font(AppFont.montserrat(13, .semibold, relativeTo: .subheadline))
                            .foregroundStyle(AppColor.background)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 9)
                            .background(AppColor.primary, in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(16)
        .foregroundStyle(AppColor.primary)
        .background(ScheduleLoadingView.cardColor, in: RoundedRectangle(cornerRadius: 10))
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(AppColor.muted, lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.12), radius: 12, y: 4)
    }
}
