import SwiftUI

enum AppTab: Hashable {
    case home, shifts, settings
}

enum ShiftsMode: Hashable {
    case calendar, list
}

struct ContentView: View {
    @State private var selectedTab: AppTab = .home
    @State private var shiftsMode: ShiftsMode = .calendar
    @State private var shiftsFocusDate: Date = .now
    
    @StateObject private var store = ShiftStore.persistent()   // 기기에 저장된 데이터
    @StateObject private var tutorial = TutorialController()   // 튜토리얼 진행 상태
    @Environment(\.scenePhase) private var scenePhase          // 앱이 화면에 있는지
    @AppStorage(AppStorageKey.hasCompletedOnboarding) private var hasCompletedOnboarding = false
    
    var body: some View {
        ZStack {
            if hasCompletedOnboarding {
                mainTabs
                    .transition(.opacity)
            } else {
                OnboardingView()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.35), value: hasCompletedOnboarding)
        .preferredColorScheme(.light)
        .environmentObject(store)
        .environmentObject(tutorial)
        // 앱으로 돌아올 때마다 (권한 창을 닫은 직후 포함) 리마인더 다시 맞추기
        .onChange(of: scenePhase) { _, phase in
            if phase == .active {
                store.refreshReminders()
            }
        }
        // 온보딩 끝 → (Show me how를 눌렀다면) 튜토리얼 시작
        .onChange(of: hasCompletedOnboarding) { _, completed in
            if completed {
                selectedTab = .home
                tutorial.startIfPending()
            }
        }
        // 튜토리얼이 탭 이동을 요청하면 이동
        .onChange(of: tutorial.requestedTab) { _, tab in
            if let tab {
                selectedTab = tab
                tutorial.requestedTab = nil
            }
        }
    }
    
    /// 기존 Home · Shifts · Settings 탭
    private var mainTabs: some View {
        TabView(selection: $selectedTab) {
            HomeView(
                shifts: store.shifts,
                onOpenCalendar: { date in
                    shiftsFocusDate = date
                    shiftsMode = .calendar
                    selectedTab = .shifts
                },
                onOpenList: {
                    shiftsFocusDate = .now
                    shiftsMode = .list
                    selectedTab = .shifts
                }
            )
            .tabItem { Label("Home", systemImage: "house") }
            .tag(AppTab.home)
            
            ShiftsView(shifts: store.shifts, mode: $shiftsMode, selectedDate: $shiftsFocusDate)
                .tabItem { Label("Shifts", systemImage: "calendar") }
                .tag(AppTab.shifts)
            
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
                .tag(AppTab.settings)
        }
        .tint(AppColor.primary)
    }
}

#Preview {
    ContentView()
}
