import SwiftUI

/// 기기에 저장하는 값의 이름 (오타 방지용으로 한곳에 모음)
enum AppStorageKey {
    static let userName = "userName"
    static let hasCompletedOnboarding = "hasCompletedOnboarding"
    static let tutorialPending = "tutorialPending"      // Show me how를 눌렀는지 (튜토리얼에서 사용)
}

// MARK: - 온보딩 (2페이지)

struct OnboardingView: View {
    @AppStorage(AppStorageKey.userName) private var savedName = ""
    @AppStorage(AppStorageKey.hasCompletedOnboarding) private var hasCompletedOnboarding = false
    @AppStorage(AppStorageKey.tutorialPending) private var tutorialPending = false
    
    private enum Page { case name, welcome }
    @State private var page: Page = .name
    @State private var name = ""
    @State private var didLoadName = false
    
    private var trimmedName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    var body: some View {
        ZStack {
            AppColor.background
                .ignoresSafeArea()
            
            switch page {
            case .name:
                NamePage(name: $name, onContinue: goToWelcome)
                    .transition(.move(edge: .leading).combined(with: .opacity))
            case .welcome:
                WelcomePage(
                    name: trimmedName,
                    onShowMe: { finish(withTutorial: true) },
                    onSkip: { finish(withTutorial: false) },
                    onBack: {
                        withAnimation(.spring(duration: 0.5, bounce: 0.2)) { page = .name }
                    }
                )
                .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
        .foregroundStyle(AppColor.primary)
        .onAppear {
            // 저장된 이름이 있으면 미리 채우기 (한 번만)
            if !didLoadName {
                name = savedName
                didLoadName = true
            }
        }
    }
    
    private func goToWelcome() {
        guard !trimmedName.isEmpty else { return }
        savedName = trimmedName
        withAnimation(.spring(duration: 0.5, bounce: 0.2)) {
            page = .welcome
        }
    }
    
    private func finish(withTutorial: Bool) {
        tutorialPending = withTutorial
        hasCompletedOnboarding = true
    }
}

// MARK: - Page 1: Name

private struct NamePage: View {
    @Binding var name: String
    let onContinue: () -> Void
    
    @FocusState private var isFocused: Bool
    @State private var appeared = false
    
    private var trimmed: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    /// 입력 중이면 입력창을 내려다보고, 글자가 늘수록 눈이 오른쪽으로
    private var look: CGSize {
        guard isFocused else { return .zero }
        let progress = CGFloat(min(name.count, 14)) / 14
        return CGSize(width: -0.6 + 1.2 * progress, height: 1)
    }
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 40)
            
            IdleMascot(size: 96, look: look)
                .animation(.spring(duration: 0.35, bounce: 0.3), value: look)
                .scaleEffect(appeared ? 1 : 0.6)
                .opacity(appeared ? 1 : 0)
            
            Text("What should I call you?")
                .font(AppFont.montserrat(26, .bold, relativeTo: .largeTitle))
                .padding(.top, 32)
            
            Text("Let’s make things personal.")
                .font(AppFont.montserrat(13, relativeTo: .subheadline))
                .foregroundStyle(AppColor.primary.opacity(0.7))
                .padding(.top, 6)
            
            TextField("Your name", text: $name)
                .font(AppFont.montserrat(16, relativeTo: .body))
                .textInputAutocapitalization(.words)
                .autocorrectionDisabled()
                .focused($isFocused)
                .submitLabel(.continue)
                .onSubmit {
                    if !trimmed.isEmpty { onContinue() }
                }
                .padding(.horizontal, 16)
                .frame(minHeight: 52)
                .cardStyle()
                .padding(.top, 28)
            
            Spacer()
            Spacer()
        }
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)
        .frame(maxWidth: 480)
        .safeAreaInset(edge: .bottom) {
            PrimaryButton(title: "Continue", minHeight: 52) {
                onContinue()
            }
            .disabled(trimmed.isEmpty)
            .padding(.horizontal, 24)
            .padding(.bottom, 8)
            .frame(maxWidth: 480)
        }
        .onAppear {
            withAnimation(.spring(duration: 0.6, bounce: 0.4).delay(0.1)) {
                appeared = true
            }
        }
    }
}

// MARK: - Page 2: Welcome

private struct WelcomePage: View {
    let name: String
    let onShowMe: () -> Void
    let onSkip: () -> Void
    let onBack: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 40)
            
            IdleMascot(size: 96, mood: .happy)
            
            Text("Nice to meet you, \(name)!")
                .font(AppFont.montserrat(26, .bold, relativeTo: .largeTitle))
                .padding(.top, 32)
            
            Text("Want me to show you around?")
                .font(AppFont.montserrat(13, relativeTo: .subheadline))
                .foregroundStyle(AppColor.primary.opacity(0.7))
                .padding(.top, 6)
            
            Spacer()
            Spacer()
        }
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)
        .frame(maxWidth: 480)
        .safeAreaInset(edge: .bottom) {
            VStack(spacing: 16) {
                PrimaryButton(title: "Show me how", minHeight: 52, action: onShowMe)
                
                Button(action: onSkip) {
                    Text("Skip for now")
                        .font(AppFont.montserrat(13, .medium, relativeTo: .subheadline))
                        .underline()
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 8)
            .frame(maxWidth: 480)
        }
        .overlay(alignment: .topLeading) {
            Button(action: onBack) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 17, weight: .semibold))
                    .frame(width: 44, height: 44)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Back")
            .padding(.leading, 12)
        }
    }
}

// MARK: - 가만히 있는 마스코트 (숨쉬기·깜빡임·시선 / 기쁘게 통통)

struct IdleMascot: View {
    enum Mood { case calm, happy }
    
    var size: CGFloat = 96
    var mood: Mood = .calm
    var look: CGSize = .zero
    
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var startDate = Date()
    
    var body: some View {
        TimelineView(.animation) { context in
            let time = context.date.timeIntervalSince(startDate)
            let pose = reduceMotion ? IdleMotion.Pose() : IdleMotion.pose(at: time, mood: mood)
            
            MascotView(
                size: size,
                expression: mood == .happy ? .happy : .normal,
                eyeOpenness: mood == .happy ? 1 : MascotMotion.eyeOpenness(at: time),
                lookOffset: look,
                squash: pose.squash,
                hop: pose.hop
            )
        }
    }
}

enum IdleMotion {
    struct Pose {
        var hop: CGFloat = 0
        var squash: CGFloat = 0
    }
    
    static func pose(at time: TimeInterval, mood: IdleMascot.Mood) -> Pose {
        switch mood {
        case .calm:
            // 숨 쉬듯 아주 살짝 출렁
            return Pose(hop: 0, squash: CGFloat(0.12 * sin(time * 2.2)))
        case .happy:
            // 통통 뛰기: 공중에서는 쭉 늘어나고, 착지하면 눌렸다가 출렁
            let period = 1.1
            let p = time.truncatingRemainder(dividingBy: period) / period
            if p < 0.45 {
                let s = sin(Double.pi * p / 0.45)
                return Pose(hop: CGFloat(0.35 * s), squash: CGFloat(-0.35 * s))
            } else {
                let u = (p - 0.45) / 0.55
                return Pose(hop: 0, squash: CGFloat(0.5 * exp(-4 * u) * sin(3 * Double.pi * u)))
            }
        }
    }
}

// MARK: - 개발용: 온보딩 다시 보기 (TODO: 출시 전 삭제)

struct OnboardingResetRow: View {
    @AppStorage(AppStorageKey.hasCompletedOnboarding) private var hasCompletedOnboarding = true
    @AppStorage(AppStorageKey.userName) private var userName = ""
    
    var body: some View {
        Button("Show onboarding again") {
            if userName.isEmpty { userName = "Jiwoo" }   // 키보드 버그 대비: 이름 미리 채우기
            hasCompletedOnboarding = false
        }
    }
}

#Preview {
    OnboardingView()
}
