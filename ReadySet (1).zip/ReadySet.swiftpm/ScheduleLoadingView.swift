import SwiftUI

/// 근무표를 분석하는 동안 화면 위에 띄우는 카드 (캐릭터 + 문구)
/// isFinished가 true가 되면 캐릭터가 눈웃음 완료 모션을 보여줘요.
struct ScheduleLoadingView: View {
    var isFinished = false
    var title = "Finding your shifts…"
    var message = "Looking through your work schedule."
    
    /// 캐릭터가 자연스럽게 어울리도록 카드에 깔리는 아주 연한 보라
    static let cardColor = Color(hex: 0xF6F4FF)
    
    var body: some View {
        ZStack {
            // 뒤 화면을 살짝 어둡게 + 터치 막기
            Color.black.opacity(0.25)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                AnimatedMascot(size: 100, style: .bouncy, isFinished: isFinished, cycleDuration: 3.6, showsDropShadow: false)
                
                Text(title)
                    .font(AppFont.montserrat(17, .semibold, relativeTo: .headline))
                    .padding(.top, 20)
                
                Text(message)
                    .font(AppFont.montserrat(13, relativeTo: .subheadline))
                    .foregroundStyle(AppColor.primary.opacity(0.7))
                    .padding(.top, 6)
            }
            .multilineTextAlignment(.center)
            .foregroundStyle(AppColor.primary)
            .padding(.top, 32)
            .padding(.bottom, 28)
            .padding(.horizontal, 28)
            .frame(maxWidth: 300)
            .background(Self.cardColor, in: RoundedRectangle(cornerRadius: 10))
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(AppColor.muted, lineWidth: 1)
            )
            .padding(24)
        }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isModal)
    }
}

#Preview("Loading") {
    ScheduleLoadingView()
}

#Preview("Finished") {
    ScheduleLoadingView(isFinished: true)
}
