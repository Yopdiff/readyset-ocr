import SwiftUI

struct HomeView: View {
    let shifts: [Shift]
    var onOpenCalendar: (Date) -> Void = { _ in }   // NEXT SHIFT › 눌렀을 때
    var onOpenList: () -> Void = { }                // See all › 눌렀을 때
    
    @EnvironmentObject private var tutorial: TutorialController
    @State private var isShowingAddSchedule = false
    
    var body: some View {
        let now = Date.now
        let futureShifts = ShiftSchedule.futureShifts(in: shifts, after: now)
        let nextShift = futureShifts.first
        let upcoming = Array(futureShifts.dropFirst().prefix(2))   // 다음 근무 이후 2개
        
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    HomeHeader(
                        date: now,
                        isDayOff: !ShiftSchedule.hasShift(in: shifts, on: now),
                        onAddTapped: openAddSchedule
                    )
                    .padding(.top, 24)
                    
                    if let nextShift {
                        // 근무가 있을 때
                        NextShiftCard(shift: nextShift, now: now) {
                            onOpenCalendar(nextShift.start)
                        }
                        .padding(.top, 24)
                        
                        if !upcoming.isEmpty {
                            UpcomingShiftsSection(shifts: upcoming, onSeeAll: onOpenList)
                                .padding(.top, 28)
                        }
                        
                        AddScheduleButton(action: openAddSchedule)
                            .tutorialTarget(.addScheduleButton)
                            .padding(.top, 20)
                    } else {
                        // 근무가 없을 때
                        EmptyShiftsView()
                            .padding(.top, 64)
                        
                        PrimaryButton(title: "Add your first schedule", systemImage: "plus") {
                            openAddSchedule()
                        }
                        .tutorialTarget(.addScheduleButton)
                        .padding(.top, 40)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
            .background(AppColor.background)
            .toolbar(.hidden, for: .navigationBar)
            .tutorialOverlay(tutorial, showing: [.addSchedule, .shiftsAdded]) { step in
                if step == .shiftsAdded {
                    tutorial.goToSettings()
                }
            }
            .navigationDestination(isPresented: $isShowingAddSchedule) {
                AddScheduleView(onFinish: { isShowingAddSchedule = false })
            }
        }
    }
    
    private func openAddSchedule() {
        tutorial.advance(from: .addSchedule, to: .choosePhoto)
        isShowingAddSchedule = true
    }
}

#Preview("With shifts") {
    HomeView(shifts: SampleData.shifts)
        .environmentObject(ShiftStore.sample)
        .environmentObject(TutorialController())
}

#Preview("Empty") {
    HomeView(shifts: [])
        .environmentObject(ShiftStore.sample)
        .environmentObject(TutorialController())
}
